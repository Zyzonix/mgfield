from . import command_line

if __name__ == "__main__":
    command_line.main()
